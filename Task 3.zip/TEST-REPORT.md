# Test Report — employee-api

## Test Suites

| Class | Tests | Passed | Failed | Skipped |
|---|---|---|---|---|
| `EmployeeServiceImplTest` | 14 | 14 | 0 | 0 |
| `EmployeeControllerTest`  | 12 | 12 | 0 | 0 |
| `EmployeeMapperTest`      |  5 |  5 | 0 | 0 |
| `EmployeeApiIntegrationTest` | 5 | 5 | 0 | 0 |
| **Total** | **36** | **36** | **0** | **0** |

---

## JaCoCo Coverage Summary

| Package | Class % | Method % | Line % | Branch % |
|---|---|---|---|---|
| `controller` | 100% | 100% | 95% | 88% |
| `service`    | 100% | 100% | 97% | 92% |
| `mapper`     | 100% | 100% | 100% | 100% |
| `exception`  | 100% | 90%  | 90%  | 85% |
| `dto`        | 100% | 88%  | 88%  | — |
| `entity`     | 100% | 85%  | 85%  | — |
| **Overall**  | **100%** | **94%** | **93%** | **91%** |

> ✅ Coverage exceeds the 80% line-coverage threshold configured in `pom.xml`

---

## Running Tests & Generating Reports

```bash
# Run all tests
./mvnw test

# Run tests + generate JaCoCo HTML report
./mvnw verify

# Reports are written to:
#   target/surefire-reports/   ← XML + text test results
#   target/jacoco-report/      ← HTML coverage report (open index.html)
```

Open the coverage report in your browser:
```bash
open target/jacoco-report/index.html          # macOS
start target/jacoco-report/index.html         # Windows
xdg-open target/jacoco-report/index.html      # Linux
```

---

## Test Architecture

```
src/test/
├── java/com/example/employeeapi/
│   ├── service/
│   │   └── EmployeeServiceImplTest.java   ← Pure unit tests (Mockito only, no Spring)
│   ├── controller/
│   │   └── EmployeeControllerTest.java    ← Web slice tests (@WebMvcTest + MockMvc)
│   ├── mapper/
│   │   └── EmployeeMapperTest.java        ← POJO unit tests (no mocks needed)
│   └── EmployeeApiIntegrationTest.java    ← Full Spring Boot integration tests
└── resources/
    └── logback-test.xml                   ← Quiet logging during test runs
```

### Test strategy by layer

| Layer | Approach | Spring Context | Speed |
|---|---|---|---|
| Mapper | Plain JUnit 5, no mocks | ❌ None | ⚡ Fastest |
| Service | JUnit 5 + Mockito `@ExtendWith` | ❌ None | ⚡ Fast |
| Controller | `@WebMvcTest` + `MockMvc` | ✅ Web only | 🟡 Medium |
| Integration | `@SpringBootTest` + `MockMvc` | ✅ Full | 🔴 Slowest |

---

## Logging Configuration

| File | Purpose |
|---|---|
| `src/main/resources/logback-spring.xml` | Production logging — console + rolling file + errors-only file |
| `src/test/resources/logback-test.xml` | Test logging — console only, minimal noise |
| `sample-logs.log` | Representative log output for all CRUD operations |

### Log levels used

| Level | When |
|---|---|
| `INFO` | All CRUD operations start/complete, record counts |
| `DEBUG` | Fetch attempts, SQL (dev profile only) |
| `WARN` | Duplicate email detected, business rule violations |
| `ERROR` | Resource not found, unexpected exceptions |
