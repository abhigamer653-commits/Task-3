package com.example.employeeapi.service;

import com.example.employeeapi.dto.EmployeeRequestDTO;
import com.example.employeeapi.dto.EmployeeResponseDTO;
import com.example.employeeapi.entity.Employee;
import com.example.employeeapi.exception.DuplicateResourceException;
import com.example.employeeapi.exception.ResourceNotFoundException;
import com.example.employeeapi.mapper.EmployeeMapper;
import com.example.employeeapi.repository.EmployeeRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Pure unit tests for EmployeeServiceImpl.
 * Dependencies (repository, mapper) are mocked with Mockito —
 * no Spring context is loaded, so tests run in milliseconds.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("EmployeeServiceImpl Unit Tests")
class EmployeeServiceImplTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private EmployeeMapper employeeMapper;

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    // ── Shared fixtures ──────────────────────────────────────────────────

    private EmployeeRequestDTO buildRequest() {
        return EmployeeRequestDTO.builder()
                .firstName("Alice")
                .lastName("Smith")
                .email("alice@example.com")
                .department("Engineering")
                .jobTitle("Software Engineer")
                .salary(90000.0)
                .hireDate(LocalDate.of(2022, 3, 1))
                .build();
    }

    private Employee buildEmployee(Long id) {
        Employee e = new Employee();
        e.setId(id);
        e.setFirstName("Alice");
        e.setLastName("Smith");
        e.setEmail("alice@example.com");
        e.setDepartment("Engineering");
        e.setJobTitle("Software Engineer");
        e.setSalary(90000.0);
        e.setHireDate(LocalDate.of(2022, 3, 1));
        e.setCreatedAt(LocalDateTime.now());
        e.setUpdatedAt(LocalDateTime.now());
        return e;
    }

    private EmployeeResponseDTO buildResponse(Long id) {
        return EmployeeResponseDTO.builder()
                .id(id)
                .firstName("Alice")
                .lastName("Smith")
                .email("alice@example.com")
                .department("Engineering")
                .jobTitle("Software Engineer")
                .salary(90000.0)
                .hireDate(LocalDate.of(2022, 3, 1))
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    // ════════════════════════════════════════════════════════════════════
    //  CREATE
    // ════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("createEmployee()")
    class CreateEmployeeTests {

        @Test
        @DisplayName("should create and return employee when email is unique")
        void createEmployee_success() {
            EmployeeRequestDTO request = buildRequest();
            Employee entity   = buildEmployee(1L);
            EmployeeResponseDTO response = buildResponse(1L);

            when(employeeRepository.existsByEmail(request.getEmail())).thenReturn(false);
            when(employeeMapper.toEntity(request)).thenReturn(entity);
            when(employeeRepository.save(entity)).thenReturn(entity);
            when(employeeMapper.toResponseDTO(entity)).thenReturn(response);

            EmployeeResponseDTO result = employeeService.createEmployee(request);

            assertThat(result).isNotNull();
            assertThat(result.getId()).isEqualTo(1L);
            assertThat(result.getEmail()).isEqualTo("alice@example.com");

            verify(employeeRepository).existsByEmail("alice@example.com");
            verify(employeeRepository).save(entity);
            verify(employeeMapper).toEntity(request);
            verify(employeeMapper).toResponseDTO(entity);
        }

        @Test
        @DisplayName("should throw DuplicateResourceException when email already exists")
        void createEmployee_duplicateEmail_throwsException() {
            EmployeeRequestDTO request = buildRequest();
            when(employeeRepository.existsByEmail(request.getEmail())).thenReturn(true);

            assertThatThrownBy(() -> employeeService.createEmployee(request))
                    .isInstanceOf(DuplicateResourceException.class)
                    .hasMessageContaining("alice@example.com");

            verify(employeeRepository, never()).save(any());
        }

        @Test
        @DisplayName("should never call save when duplicate is detected")
        void createEmployee_duplicate_neverSaves() {
            when(employeeRepository.existsByEmail(anyString())).thenReturn(true);

            assertThatThrownBy(() -> employeeService.createEmployee(buildRequest()))
                    .isInstanceOf(DuplicateResourceException.class);

            verifyNoMoreInteractions(employeeRepository);
            verifyNoInteractions(employeeMapper);
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  READ
    // ════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("getEmployeeById()")
    class GetByIdTests {

        @Test
        @DisplayName("should return employee DTO when found")
        void getById_success() {
            Employee entity = buildEmployee(1L);
            EmployeeResponseDTO response = buildResponse(1L);

            when(employeeRepository.findById(1L)).thenReturn(Optional.of(entity));
            when(employeeMapper.toResponseDTO(entity)).thenReturn(response);

            EmployeeResponseDTO result = employeeService.getEmployeeById(1L);

            assertThat(result).isNotNull();
            assertThat(result.getId()).isEqualTo(1L);
            verify(employeeRepository).findById(1L);
        }

        @Test
        @DisplayName("should throw ResourceNotFoundException when id not found")
        void getById_notFound_throwsException() {
            when(employeeRepository.findById(99L)).thenReturn(Optional.empty());

            assertThatThrownBy(() -> employeeService.getEmployeeById(99L))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("99");
        }
    }

    @Nested
    @DisplayName("getAllEmployees()")
    class GetAllTests {

        @Test
        @DisplayName("should return list of all employees")
        void getAllEmployees_returnsList() {
            Employee e1 = buildEmployee(1L);
            Employee e2 = buildEmployee(2L);
            e2.setEmail("bob@example.com");

            EmployeeResponseDTO r1 = buildResponse(1L);
            EmployeeResponseDTO r2 = buildResponse(2L);

            when(employeeRepository.findAll()).thenReturn(List.of(e1, e2));
            when(employeeMapper.toResponseDTO(e1)).thenReturn(r1);
            when(employeeMapper.toResponseDTO(e2)).thenReturn(r2);

            List<EmployeeResponseDTO> result = employeeService.getAllEmployees();

            assertThat(result).hasSize(2);
            verify(employeeRepository).findAll();
            verify(employeeMapper, times(2)).toResponseDTO(any(Employee.class));
        }

        @Test
        @DisplayName("should return empty list when no employees exist")
        void getAllEmployees_emptyList() {
            when(employeeRepository.findAll()).thenReturn(List.of());

            List<EmployeeResponseDTO> result = employeeService.getAllEmployees();

            assertThat(result).isEmpty();
            verify(employeeMapper, never()).toResponseDTO(any());
        }
    }

    @Nested
    @DisplayName("getEmployeesByDepartment()")
    class GetByDepartmentTests {

        @Test
        @DisplayName("should return employees filtered by department")
        void getByDepartment_returnsList() {
            Employee e = buildEmployee(1L);
            EmployeeResponseDTO r = buildResponse(1L);

            when(employeeRepository.findByDepartmentIgnoreCase("Engineering"))
                    .thenReturn(List.of(e));
            when(employeeMapper.toResponseDTO(e)).thenReturn(r);

            List<EmployeeResponseDTO> result =
                    employeeService.getEmployeesByDepartment("Engineering");

            assertThat(result).hasSize(1);
            assertThat(result.get(0).getDepartment()).isEqualTo("Engineering");
        }

        @Test
        @DisplayName("should return empty list when department has no employees")
        void getByDepartment_emptyDepartment() {
            when(employeeRepository.findByDepartmentIgnoreCase("HR"))
                    .thenReturn(List.of());

            List<EmployeeResponseDTO> result =
                    employeeService.getEmployeesByDepartment("HR");

            assertThat(result).isEmpty();
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  UPDATE
    // ════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("updateEmployee()")
    class UpdateEmployeeTests {

        @Test
        @DisplayName("should update employee when same email is kept")
        void updateEmployee_sameEmail_success() {
            Employee existing = buildEmployee(1L);
            EmployeeRequestDTO request = buildRequest(); // same email
            EmployeeResponseDTO response = buildResponse(1L);

            when(employeeRepository.findById(1L)).thenReturn(Optional.of(existing));
            // same email → no duplicate check needed
            when(employeeRepository.save(existing)).thenReturn(existing);
            when(employeeMapper.toResponseDTO(existing)).thenReturn(response);

            EmployeeResponseDTO result = employeeService.updateEmployee(1L, request);

            assertThat(result).isNotNull();
            verify(employeeMapper).updateEntityFromDTO(request, existing);
            verify(employeeRepository).save(existing);
        }

        @Test
        @DisplayName("should update employee when email changes to a unique value")
        void updateEmployee_newUniqueEmail_success() {
            Employee existing = buildEmployee(1L);
            EmployeeRequestDTO request = buildRequest();
            request.setEmail("newalice@example.com");

            EmployeeResponseDTO response = buildResponse(1L);
            response.setEmail("newalice@example.com");

            when(employeeRepository.findById(1L)).thenReturn(Optional.of(existing));
            when(employeeRepository.existsByEmail("newalice@example.com")).thenReturn(false);
            when(employeeRepository.save(existing)).thenReturn(existing);
            when(employeeMapper.toResponseDTO(existing)).thenReturn(response);

            EmployeeResponseDTO result = employeeService.updateEmployee(1L, request);

            assertThat(result.getEmail()).isEqualTo("newalice@example.com");
        }

        @Test
        @DisplayName("should throw DuplicateResourceException when new email is taken")
        void updateEmployee_emailTaken_throwsException() {
            Employee existing = buildEmployee(1L);
            EmployeeRequestDTO request = buildRequest();
            request.setEmail("taken@example.com");

            when(employeeRepository.findById(1L)).thenReturn(Optional.of(existing));
            when(employeeRepository.existsByEmail("taken@example.com")).thenReturn(true);

            assertThatThrownBy(() -> employeeService.updateEmployee(1L, request))
                    .isInstanceOf(DuplicateResourceException.class)
                    .hasMessageContaining("taken@example.com");

            verify(employeeRepository, never()).save(any());
        }

        @Test
        @DisplayName("should throw ResourceNotFoundException when employee to update not found")
        void updateEmployee_notFound_throwsException() {
            when(employeeRepository.findById(99L)).thenReturn(Optional.empty());

            assertThatThrownBy(() -> employeeService.updateEmployee(99L, buildRequest()))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("99");
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  DELETE
    // ════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("deleteEmployee()")
    class DeleteEmployeeTests {

        @Test
        @DisplayName("should delete employee successfully when found")
        void deleteEmployee_success() {
            Employee employee = buildEmployee(1L);
            when(employeeRepository.findById(1L)).thenReturn(Optional.of(employee));

            assertThatCode(() -> employeeService.deleteEmployee(1L))
                    .doesNotThrowAnyException();

            verify(employeeRepository).delete(employee);
        }

        @Test
        @DisplayName("should throw ResourceNotFoundException when employee to delete not found")
        void deleteEmployee_notFound_throwsException() {
            when(employeeRepository.findById(99L)).thenReturn(Optional.empty());

            assertThatThrownBy(() -> employeeService.deleteEmployee(99L))
                    .isInstanceOf(ResourceNotFoundException.class)
                    .hasMessageContaining("99");

            verify(employeeRepository, never()).delete(any());
        }
    }
}
