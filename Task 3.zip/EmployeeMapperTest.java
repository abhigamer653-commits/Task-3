package com.example.employeeapi.mapper;

import com.example.employeeapi.dto.EmployeeRequestDTO;
import com.example.employeeapi.dto.EmployeeResponseDTO;
import com.example.employeeapi.entity.Employee;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;

@DisplayName("EmployeeMapper Unit Tests")
class EmployeeMapperTest {

    private final EmployeeMapper mapper = new EmployeeMapper();

    private EmployeeRequestDTO buildRequest() {
        return EmployeeRequestDTO.builder()
                .firstName("Bob")
                .lastName("Jones")
                .email("bob@example.com")
                .department("HR")
                .jobTitle("HR Manager")
                .salary(75000.0)
                .hireDate(LocalDate.of(2021, 5, 10))
                .build();
    }

    private Employee buildEmployee() {
        Employee e = new Employee();
        e.setId(1L);
        e.setFirstName("Bob");
        e.setLastName("Jones");
        e.setEmail("bob@example.com");
        e.setDepartment("HR");
        e.setJobTitle("HR Manager");
        e.setSalary(75000.0);
        e.setHireDate(LocalDate.of(2021, 5, 10));
        e.setCreatedAt(LocalDateTime.of(2024, 1, 1, 10, 0));
        e.setUpdatedAt(LocalDateTime.of(2024, 6, 1, 12, 0));
        return e;
    }

    @Nested
    @DisplayName("toEntity()")
    class ToEntityTests {

        @Test
        @DisplayName("should map all fields from DTO to entity")
        void toEntity_mapsAllFields() {
            EmployeeRequestDTO dto = buildRequest();

            Employee result = mapper.toEntity(dto);

            assertThat(result.getFirstName()).isEqualTo("Bob");
            assertThat(result.getLastName()).isEqualTo("Jones");
            assertThat(result.getEmail()).isEqualTo("bob@example.com");
            assertThat(result.getDepartment()).isEqualTo("HR");
            assertThat(result.getJobTitle()).isEqualTo("HR Manager");
            assertThat(result.getSalary()).isEqualTo(75000.0);
            assertThat(result.getHireDate()).isEqualTo(LocalDate.of(2021, 5, 10));
        }

        @Test
        @DisplayName("should not set id (it is auto-generated)")
        void toEntity_doesNotSetId() {
            Employee result = mapper.toEntity(buildRequest());
            assertThat(result.getId()).isNull();
        }
    }

    @Nested
    @DisplayName("toResponseDTO()")
    class ToResponseDTOTests {

        @Test
        @DisplayName("should map all fields from entity to response DTO")
        void toResponseDTO_mapsAllFields() {
            Employee entity = buildEmployee();

            EmployeeResponseDTO result = mapper.toResponseDTO(entity);

            assertThat(result.getId()).isEqualTo(1L);
            assertThat(result.getFirstName()).isEqualTo("Bob");
            assertThat(result.getLastName()).isEqualTo("Jones");
            assertThat(result.getEmail()).isEqualTo("bob@example.com");
            assertThat(result.getDepartment()).isEqualTo("HR");
            assertThat(result.getJobTitle()).isEqualTo("HR Manager");
            assertThat(result.getSalary()).isEqualTo(75000.0);
            assertThat(result.getHireDate()).isEqualTo(LocalDate.of(2021, 5, 10));
            assertThat(result.getCreatedAt()).isEqualTo(LocalDateTime.of(2024, 1, 1, 10, 0));
            assertThat(result.getUpdatedAt()).isEqualTo(LocalDateTime.of(2024, 6, 1, 12, 0));
        }
    }

    @Nested
    @DisplayName("updateEntityFromDTO()")
    class UpdateEntityTests {

        @Test
        @DisplayName("should overwrite all mutable entity fields from DTO")
        void updateEntity_overwritesFields() {
            Employee entity = buildEmployee();
            EmployeeRequestDTO dto = buildRequest();
            dto.setFirstName("Robert");
            dto.setEmail("robert@example.com");
            dto.setSalary(85000.0);

            mapper.updateEntityFromDTO(dto, entity);

            assertThat(entity.getFirstName()).isEqualTo("Robert");
            assertThat(entity.getEmail()).isEqualTo("robert@example.com");
            assertThat(entity.getSalary()).isEqualTo(85000.0);
            // unchanged fields stay
            assertThat(entity.getId()).isEqualTo(1L);
        }
    }
}
