package com.example.employeeapi.controller;

import com.example.employeeapi.dto.EmployeeRequestDTO;
import com.example.employeeapi.dto.EmployeeResponseDTO;
import com.example.employeeapi.exception.DuplicateResourceException;
import com.example.employeeapi.exception.GlobalExceptionHandler;
import com.example.employeeapi.exception.ResourceNotFoundException;
import com.example.employeeapi.service.EmployeeService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Slice test — loads only the web layer (no JPA, no real services).
 * EmployeeService is replaced with a Mockito mock.
 */
@WebMvcTest(EmployeeController.class)
@Import(GlobalExceptionHandler.class)
@DisplayName("EmployeeController Web Layer Tests")
class EmployeeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private EmployeeService employeeService;

    // ── fixtures ────────────────────────────────────────────────────────

    private EmployeeRequestDTO validRequest() {
        return EmployeeRequestDTO.builder()
                .firstName("Carol")
                .lastName("White")
                .email("carol@example.com")
                .department("Finance")
                .jobTitle("Analyst")
                .salary(80000.0)
                .hireDate(LocalDate.of(2023, 1, 15))
                .build();
    }

    private EmployeeResponseDTO buildResponse(Long id) {
        return EmployeeResponseDTO.builder()
                .id(id)
                .firstName("Carol")
                .lastName("White")
                .email("carol@example.com")
                .department("Finance")
                .jobTitle("Analyst")
                .salary(80000.0)
                .hireDate(LocalDate.of(2023, 1, 15))
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    // ════════════════════════════════════════════════════════════════════
    //  POST
    // ════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("POST /api/v1/employees")
    class PostTests {

        @Test
        @DisplayName("201 Created with valid request body")
        void create_validRequest_returns201() throws Exception {
            when(employeeService.createEmployee(any())).thenReturn(buildResponse(1L));

            mockMvc.perform(post("/api/v1/employees")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(validRequest())))
                    .andDo(print())
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.success").value(true))
                    .andExpect(jsonPath("$.data.id").value(1))
                    .andExpect(jsonPath("$.data.email").value("carol@example.com"));
        }

        @Test
        @DisplayName("400 Bad Request when firstName is blank")
        void create_blankFirstName_returns400() throws Exception {
            EmployeeRequestDTO invalid = validRequest();
            invalid.setFirstName("");

            mockMvc.perform(post("/api/v1/employees")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(invalid)))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.success").value(false))
                    .andExpect(jsonPath("$.data.firstName").exists());
        }

        @Test
        @DisplayName("400 Bad Request when email is invalid")
        void create_invalidEmail_returns400() throws Exception {
            EmployeeRequestDTO invalid = validRequest();
            invalid.setEmail("not-an-email");

            mockMvc.perform(post("/api/v1/employees")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(invalid)))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.data.email").exists());
        }

        @Test
        @DisplayName("400 Bad Request when salary is zero")
        void create_zeroSalary_returns400() throws Exception {
            EmployeeRequestDTO invalid = validRequest();
            invalid.setSalary(0.0);

            mockMvc.perform(post("/api/v1/employees")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(invalid)))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.data.salary").exists());
        }

        @Test
        @DisplayName("409 Conflict when email already exists")
        void create_duplicateEmail_returns409() throws Exception {
            when(employeeService.createEmployee(any()))
                    .thenThrow(new DuplicateResourceException("Email already exists"));

            mockMvc.perform(post("/api/v1/employees")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(validRequest())))
                    .andExpect(status().isConflict())
                    .andExpect(jsonPath("$.success").value(false));
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  GET
    // ════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("GET /api/v1/employees")
    class GetTests {

        @Test
        @DisplayName("200 OK — returns list of all employees")
        void getAll_returns200WithList() throws Exception {
            when(employeeService.getAllEmployees())
                    .thenReturn(List.of(buildResponse(1L), buildResponse(2L)));

            mockMvc.perform(get("/api/v1/employees"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.success").value(true))
                    .andExpect(jsonPath("$.data.length()").value(2));
        }

        @Test
        @DisplayName("200 OK — filters by department query param")
        void getByDepartment_returns200() throws Exception {
            when(employeeService.getEmployeesByDepartment("Finance"))
                    .thenReturn(List.of(buildResponse(1L)));

            mockMvc.perform(get("/api/v1/employees").param("department", "Finance"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.length()").value(1));

            verify(employeeService).getEmployeesByDepartment("Finance");
            verify(employeeService, never()).getAllEmployees();
        }

        @Test
        @DisplayName("200 OK — returns single employee by id")
        void getById_returns200() throws Exception {
            when(employeeService.getEmployeeById(1L)).thenReturn(buildResponse(1L));

            mockMvc.perform(get("/api/v1/employees/1"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.id").value(1));
        }

        @Test
        @DisplayName("404 Not Found when employee id does not exist")
        void getById_notFound_returns404() throws Exception {
            when(employeeService.getEmployeeById(99L))
                    .thenThrow(new ResourceNotFoundException("Employee not found with id: 99"));

            mockMvc.perform(get("/api/v1/employees/99"))
                    .andExpect(status().isNotFound())
                    .andExpect(jsonPath("$.success").value(false))
                    .andExpect(jsonPath("$.message").value("Employee not found with id: 99"));
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  PUT
    // ════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("PUT /api/v1/employees/{id}")
    class PutTests {

        @Test
        @DisplayName("200 OK — updates employee successfully")
        void update_returns200() throws Exception {
            EmployeeResponseDTO updated = buildResponse(1L);
            updated.setJobTitle("Senior Analyst");

            when(employeeService.updateEmployee(eq(1L), any())).thenReturn(updated);

            EmployeeRequestDTO request = validRequest();
            request.setJobTitle("Senior Analyst");

            mockMvc.perform(put("/api/v1/employees/1")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(request)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.jobTitle").value("Senior Analyst"));
        }

        @Test
        @DisplayName("404 Not Found when updating non-existent employee")
        void update_notFound_returns404() throws Exception {
            when(employeeService.updateEmployee(eq(99L), any()))
                    .thenThrow(new ResourceNotFoundException("Employee not found with id: 99"));

            mockMvc.perform(put("/api/v1/employees/99")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(validRequest())))
                    .andExpect(status().isNotFound());
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  DELETE
    // ════════════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("DELETE /api/v1/employees/{id}")
    class DeleteTests {

        @Test
        @DisplayName("200 OK — deletes employee successfully")
        void delete_returns200() throws Exception {
            doNothing().when(employeeService).deleteEmployee(1L);

            mockMvc.perform(delete("/api/v1/employees/1"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.success").value(true))
                    .andExpect(jsonPath("$.message").value("Employee deleted successfully"));
        }

        @Test
        @DisplayName("404 Not Found when deleting non-existent employee")
        void delete_notFound_returns404() throws Exception {
            doThrow(new ResourceNotFoundException("Employee not found with id: 99"))
                    .when(employeeService).deleteEmployee(99L);

            mockMvc.perform(delete("/api/v1/employees/99"))
                    .andExpect(status().isNotFound());
        }
    }
}
